# Amairee — Gifting concept handoff (paste this whole folder into the new chat)

## Tell the new chat:
"Continue the Amairee gifting work. Read READ_ME_FIRST.md. Everything stays ISOLATED — do not wire into live pages until I say so. Edit `gifting_generator.py`, not the HTML."

## What Amairee is
Personalised luxury luggage e-commerce (India). USP / moat: **patented** product, **India's only manufacturer**, **in-house** design + production + QC, **any quantity always in stock**, **limitless personalisation**, **best-in-class workmanship**, quality-first. Ships India + US + UK + Canada in **2–7 days**. Made in Delhi, India. WhatsApp +91 99111 12624 · @amaireeofficial · amairee.com.

## What this folder contains
- `amairee-gifting-hub-mockup.html` — the Gifting hub (hero, two-lane selector, moat section, "put anything on it" showcase, **Redesign Promise band**, occasion grid, bulk-discount ladder, **interactive quote engine**, workflow, trusted-by logos + reviews, **four-sizes band**, **Ready-made gift sets / bundles**, collaborations strip + **Partner Program strip**). Renames the old "Wedding" tab to **Gifting** and folds **Corporate** in.
- `amairee-gifting-{weddings,corporate,events,brand-launch,parties,collaborations}.html` — six occasion pages. **Weddings** now has a "Looks our couples love" gallery showcasing the reference-inspired treatments. **Corporate** carries a **full-surface sublimation band**.
- `amairee-gifting-ambassador.html` — **NEW. The Partner / Ambassador Program** (hero, who-it's-for, three tiers, how-it-works, perks, FAQs — no rates or calculator shown by design). Three tracks: Ambassador (customers), Creator (influencers), Pro Partner (planners/agencies).
- `gifting_generator.py` — the Python builder that generates ALL of the above. **Edit this, not the HTML.**
- `design_assets_b64.txt` — the real design tiles + suitcase overlays (kids/cabin/medium/large) the generator uses to render REAL product mockups.

## How the mockups work (important)
The generator renders real product mockups with `render_mockup(design_key, text, kind, size)`:
- `kind`: `name` | `logo` (brand lockup) | `monogram` | `invite` (wedding invite card) | `surface` (full-surface sublimation — whole shell becomes the brand) | `block` (one bold word: BRIDE/GROOM) | `script` (italic phrase: "Bride to be") | `mrmrs` (gold "Mr & Mrs" + surname, dark tile) | `est` (HUBBY/WIFEY + diamond + EST date, text="WIFEY|12.04.26", dark tile) | `bigname` (big muted surname-word + script first name + EST, text="MRS|Johnson|EST 2026", dark tile)
- `size`: `kids` | `cabin` | `medium` | `large` (uses the matching overlay)
- It composites: white bg → design tile (cover-fit) → artwork (draw_face) → real suitcase overlay on top, then embeds as base64 JPEG.
- Pair `surface`/`mrmrs`/`est`/`bigname` with a DARK tile (e.g. `D_MIDNIGHT`); pair `block`/`script` with a light/colour tile (e.g. `D_BLUSH_FLORAL`, `D_BUTTER_CREAM`).
- NOTE on the reference images: the founder's uploads were real photos from another brand (some watermarked). We did NOT embed those — instead we recreated those popular wedding styles as ORIGINAL Amairee mockups via the generator.

## To regenerate after editing
1. The assets path is now robust (loads `design_assets_b64.txt` from the script's own folder) and `OUT='/mnt/user-data/outputs'` is auto-created.
2. Run `python3 gifting_generator.py`. Verify each file: div/section balance, then present.
   (Validated this build: all files div- and section-balanced; mockups render correctly.)

## DONE since last handoff
- **Full-surface "YOUR LOGO HERE" sublimated treatment** (the pending task): the founder's reference image was incorporated. Added a new `surface` render kind (dark shell + keyline frame + brand wordmark + "FULL-SURFACE SUBLIMATION" caption). It now appears as:
  - the 5th tile ("Your whole brand") in the hub's "Put anything on it" showcase,
  - the **Corporate hero piece**, and
  - a dedicated **"Make the whole case your brand"** band on the Corporate page.
- **The Redesign Promise** ("a gift that's never wasted"): any piece can return to be re-skinned with a new design for a small refresh fee. Added as a band on the hub, a closing-CTA reassurance line on every occasion page, and a shared FAQ on all six occasion pages.

## Recent decisions / preferences (do not re-litigate)
- Heart icon was rejected — use plain "Made in Delhi, India" (no heart).
- Transparency/cut-out mockups were tried and rejected — keep white-background mockups.
- Use the REAL mockup generator (not flat vector drawings).
- Logos and reviews on the hub are data-driven arrays (`LOGOS`, `REVIEWS`) — on the live site these come from the admin panel.
- The Redesign Promise refresh fee is confirmed at **₹1,200–2,000 depending on size** (now stated on the hub band/step and every occasion FAQ).
- Occasion copy is benefit-led (branded visibility, honeymoon/registry, group identity, no school mix-ups) but in Amairee's restrained voice — we deliberately did NOT use the source doc's stronger claims ("free advertising", ROI, "elite").
- Keep everything isolated until explicitly told to wire into the live site.

## Possible next steps (ask founder)
- **Partner Program rates are intentionally NOT shown** on the page (no % figures, no earnings calculator) — terms are described as "agreed individually when you join." If you later settle on standard rates, they can be added back; the removed calculator code is in git history / prior handoff zips.
- **Confirm bundle prices** — gift-set prices on the hub are indicative (Honeymoon Set from ₹16,500 / Bridal Party Set from ₹49,900 / Kids' Party Pack from ₹64,900 / Corporate Onboarding Kit from ₹8,100 per piece). Base single prices used: Kids ₹7,500 · Cabin ₹9,000 · Medium ₹11,000 · Large ₹13,000.
- Decide whether full-surface should also surface on the Brand Launch / Events pages (currently Corporate-only).
- Decide whether to add a "Partner Program" / "Ambassadors" link to the main nav (left nav untouched per earlier decision).
- Reuse the wedding treatments (block/script/mrmrs/est/bigname) on anniversaries (parties page) if desired.
- Add real client logos/reviews via the admin panel arrays.

## The broader project (not in this folder, ask if needed)
The full site also has: D1 homepage, D2 product page, D4 admin panel, print tool, and 10 split customer pages (cart, shop, checkout, track, account, design-your-own, gifting, gift-cards, corporate, care). Those are separate large files — only bring them over if the work moves beyond the gifting concept.
