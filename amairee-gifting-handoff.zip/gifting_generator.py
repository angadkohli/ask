import os, re, io, base64
from PIL import Image, ImageDraw, ImageFont
HERE=os.path.dirname(os.path.abspath(__file__))
OUT='/mnt/user-data/outputs'
os.makedirs(OUT, exist_ok=True)

# ---- load real assets ----
b64={}
for line in open(os.path.join(HERE,'design_assets_b64.txt')):
    if '|' in line:
        k,v=line.strip().split('|',1); b64[k]=v
import numpy as np
OVS={s:Image.open(io.BytesIO(base64.b64decode(b64['MOCKUP_'+s.upper()+'_OVERLAY']))).convert('RGBA') for s in ['kids','cabin','medium','large']}
FD='/usr/share/fonts/truetype/dejavu/'
SB=FD+'DejaVuSerif-Bold.ttf'; SI=FD+'DejaVuSerif-Italic.ttf'; SBI=FD+'DejaVuSerif-BoldItalic.ttf'; NB=FD+'DejaVuSans-Bold.ttf'
def spaced(t,n=2): return (' '*n).join(list(t))

def draw_face(d, W, H, text, kind):
    cx=W//2; ink=(34,34,34); gold=(154,117,74)
    def fit(font_path, t, maxw, start):
        fs=start
        while fs>8:
            f=ImageFont.truetype(font_path,fs); bb=d.textbbox((0,0),t,font=f)
            if bb[2]-bb[0]<=maxw: return f,bb
            fs-=2
        return ImageFont.truetype(font_path,fs), d.textbbox((0,0),t,font=ImageFont.truetype(font_path,fs))
    def center(t,font,y,fill):
        bb=d.textbbox((0,0),t,font=font); d.text((cx-(bb[2]-bb[0])//2-bb[0], y), t, font=font, fill=fill)
    if kind=='monogram':
        parts=text.split(); mono=parts[0]+'  &  '+parts[1] if len(parts)>1 else text
        f,bb=fit(SBI,mono,W*0.6,int(H*0.16)); center(mono,f,int(H*0.34),ink)
        d.line([(cx-W*0.16,H*0.52),(cx+W*0.16,H*0.52)],fill=gold,width=max(1,W//180))
    elif kind=='logo':
        m=int(W*0.045)
        d.polygon([(cx,H*0.30-m),(cx+m,H*0.30),(cx,H*0.30+m),(cx-m,H*0.30)],outline=ink,width=max(1,W//200))
        wm=spaced(text.upper(),2); f,bb=fit(NB,wm,W*0.62,int(H*0.05)); center(wm,f,int(H*0.40),ink)
        d.line([(cx-(bb[2]-bb[0])//2,H*0.40+(bb[3]-bb[1])+H*0.02),(cx+(bb[2]-bb[0])//2,H*0.40+(bb[3]-bb[1])+H*0.02)],fill=gold,width=max(1,W//240))
    elif kind=='invite':
        cw,ch=int(W*0.46),int(H*0.34); x0,y0=cx-cw//2,int(H*0.30)
        d.rounded_rectangle([x0,y0,x0+cw,y0+ch],radius=int(W*0.02),fill=(255,255,255),outline=gold,width=max(1,W//240))
        fi=ImageFont.truetype(SI,int(H*0.032)); center('together',fi,y0+int(ch*0.14),gold)
        parts=text.split(); nm=parts[0]+' & '+parts[1] if len(parts)>1 else text
        fn,_=fit(SB,nm,cw*0.8,int(H*0.05)); center(nm,fn,y0+int(ch*0.36),ink)
        d.line([(cx-cw*0.22,y0+ch*0.62),(cx+cw*0.22,y0+ch*0.62)],fill=gold,width=1)
        fd=ImageFont.truetype(NB,int(H*0.022)); center(spaced('12·12·25',1),fd,y0+int(ch*0.72),(146,138,124))
    elif kind=='surface':  # full-surface sublimation — the whole shell IS the brand
        light=(247,243,235); dim=(190,182,170); m=int(W*0.13)
        d.rounded_rectangle([m,int(H*0.205),W-m,int(H*0.795)],radius=int(W*0.015),outline=light,width=max(1,W//230))
        mm=int(W*0.032)
        d.polygon([(cx,H*0.34-mm),(cx+mm,H*0.34),(cx,H*0.34+mm),(cx-mm,H*0.34)],outline=light,width=max(1,W//240))
        wm=spaced(text.upper(),2); f,bb=fit(NB,wm,(W-2*m)*0.84,int(H*0.085)); center(wm,f,int(H*0.43),light)
        d.line([(cx-(bb[2]-bb[0])//2,H*0.43+(bb[3]-bb[1])+H*0.022),(cx+(bb[2]-bb[0])//2,H*0.43+(bb[3]-bb[1])+H*0.022)],fill=(gold[0]+40,gold[1]+30,gold[2]+20),width=max(1,W//260))
        capt=spaced('FULL-SURFACE SUBLIMATION',1); fc,_=fit(NB,capt,(W-2*m)*0.74,int(H*0.025)); center(capt,fc,int(H*0.625),dim)
    elif kind=='block':  # one bold statement word — BRIDE / GROOM / TEAM BRIDE (light/colour tile)
        word=text.upper(); f,bb=fit(NB,word,W*0.78,int(H*0.20)); center(word,f,int(H*0.40),ink)
    elif kind=='script':  # elegant italic phrase — "Bride to be" (light tile)
        blush=(193,128,128); f,bb=fit(SBI,text,W*0.70,int(H*0.11)); center(text,f,int(H*0.44),blush)
    elif kind=='mrmrs':  # "Mr & Mrs" gold script + surname (dark tile)
        light=(247,243,235); f1=ImageFont.truetype(SBI,int(H*0.085)); center('Mr  &  Mrs',f1,int(H*0.33),gold)
        fn,_=fit(SB,text.upper(),W*0.66,int(H*0.07)); center(text.upper(),fn,int(H*0.49),light)
    elif kind=='est':  # HUBBY / WIFEY + diamond + EST date — text="WIFEY|12.04.26" (dark tile)
        light=(247,243,235); parts=(text+'|').split('|'); word=parts[0].upper(); date=parts[1]
        f,bb=fit(NB,spaced(word,2),W*0.72,int(H*0.105)); center(spaced(word,2),f,int(H*0.34),light)
        mm=int(W*0.022); yy=int(H*0.50); d.polygon([(cx,yy-mm),(cx+mm,yy),(cx,yy+mm),(cx-mm,yy)],fill=gold)
        if date: fd=ImageFont.truetype(NB,int(H*0.032)); center('EST '+spaced(date,1),fd,int(H*0.55),light)
    elif kind=='bigname':  # big muted surname-word + script first name + EST — text="MR|Johnson|EST 2026" (dark tile)
        light=(247,243,235); parts=(text+'||').split('|'); big=parts[0].upper(); nm=parts[1]; est=parts[2]
        fb,bb=fit(NB,big,W*0.62,int(H*0.22)); center(big,fb,int(H*0.32),(116,112,106))
        if nm: fn,_=fit(SBI,nm,W*0.6,int(H*0.085)); center(nm,fn,int(H*0.45),light)
        if est: fe=ImageFont.truetype(NB,int(H*0.028)); center(spaced(est.upper(),1),fe,int(H*0.64),light)
    else:  # name
        f,bb=fit(SB,text,W*0.62,int(H*0.09)); center(text,f,int(H*0.40),ink)

_cache={}
def render_mockup(design_key, text, kind='name', size='cabin', W=360):
    key=(design_key,text,kind,size,W)
    if key in _cache: return _cache[key]
    OV=OVS.get(size,OVS['cabin']); ow,oh=OV.size; H=int(W*oh/ow)
    ov=OV.resize((W,H),Image.LANCZOS); a=np.asarray(ov)[:,:,3]
    di=Image.open(io.BytesIO(base64.b64decode(b64[design_key]))).convert('RGB')
    ar=di.width/di.height; car=W/H
    if ar>car: dh=H; dw=int(dh*ar); dx=(W-dw)//2; dy=0
    else: dw=W; dh=int(dw/ar); dx=0; dy=(H-dh)//2
    design=Image.new('RGB',(W,H),(255,255,255)); design.paste(di.resize((dw,dh)),(dx,dy))
    if text: draw_face(ImageDraw.Draw(design),W,H,text,kind)
    bm=Image.fromarray((255-a).astype('uint8'),'L')
    base=Image.new('RGBA',(W,H),(255,255,255,255)); base.paste(design,(0,0),bm)
    out=Image.alpha_composite(base,ov)
    buf=io.BytesIO(); out.convert('RGB').save(buf,'JPEG',quality=82,optimize=True)
    s='data:image/jpeg;base64,'+base64.b64encode(buf.getvalue()).decode(); _cache[key]=s; return s

def MK(design_key, text, kind='name', size='cabin', cls='mk'):
    return '<img class="'+cls+'" alt="Amairee personalised mockup" src="'+render_mockup(design_key,text,kind,size)+'">'

def show_tiles(items):
    return ''.join('<div class="show"><div class="cw">'+MK(d,t,k,s)+'</div><div class="st">'+lbl+'</div></div>' for lbl,d,t,k,s in items)

# ---- icons ----
def svg(p): return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>'
IC={'seal':'<circle cx="12" cy="9" r="5.6"/><path d="M9 13.8l-1.4 6.2 4.4-2.5 4.4 2.5-1.4-6.2"/><path d="M12 6.2l1 2 2.2.3-1.6 1.5.4 2.2-2-1.05-2 1.05.4-2.2-1.6-1.5 2.2-.3z"/>',
 'factory':'<path d="M3 21V11l5 3V11l5 3V8l8 5v8z"/><path d="M3 21h18"/><path d="M7 17.5h2M12 17.5h2M17 17.5h1"/>',
 'pen':'<path d="M12 2.5l3.2 7.5-3.2 11.5-3.2-11.5z"/><path d="M8.8 10h6.4"/><circle cx="12" cy="7" r="1"/>',
 'gear':'<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4L18 18M18 6l-1.6 1.6M7.6 16.4L6 18"/>',
 'qc':'<circle cx="10.5" cy="10.5" r="6.2"/><path d="M15 15l5 5"/><path d="M8 10.5l1.8 1.8 3.2-3.6"/>',
 'boxes':'<rect x="3" y="13" width="7.5" height="7.5" rx="1"/><rect x="13.5" y="13" width="7.5" height="7.5" rx="1"/><rect x="8.25" y="3.2" width="7.5" height="7.5" rx="1"/>',
 'mono':'<path d="M5.5 20L12 4.5 18.5 20"/><path d="M8 14h8"/><path d="M19.5 3l.5 1.6L21.6 5l-1.6.4L19.5 7l-.5-1.6L17.4 5l1.6-.4z"/>',
 'shield':'<path d="M12 2.5l8 3v6.2c0 5-3.6 8.6-8 10.8-4.4-2.2-8-5.8-8-10.8V5.5z"/><path d="M8.5 11.8l2.4 2.4 4.4-5"/>',
 'gift':'<rect x="3.5" y="9" width="17" height="11" rx="1"/><path d="M3.5 13h17"/><path d="M12 9v11"/><path d="M12 9S9.5 3.5 7 5.2 9.5 9 12 9zM12 9s2.5-5.5 5-3.8S14.5 9 12 9z"/>',
 'globe':'<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18"/>',
 'truck':'<rect x="2.5" y="6.5" width="11" height="9" rx="1"/><path d="M13.5 9.5h4l3 3v3h-7z"/><circle cx="7" cy="17.8" r="1.6"/><circle cx="17" cy="17.8" r="1.6"/>',
 'brief':'<path d="M4 5h16v10H8.5L4 19z"/><path d="M8 9h8M8 11.6h5"/>',
 'refresh':'<path d="M4.5 12a7.5 7.5 0 0 1 12.8-5.3L20 9"/><path d="M20 4.2V9h-4.8"/><path d="M19.5 12a7.5 7.5 0 0 1-12.8 5.3L4 15"/><path d="M4 19.8V15h4.8"/>'}
def I(n): return svg(IC[n])
print("assets + helpers ready; designs:", sum(1 for k in b64 if k.startswith('D_')))

CSS = r'''
:root{--cream:#FAF6EE;--cream-warm:#F4ECDC;--cream-deep:#EFE4CB;--ink:#1A1A1A;--ink-soft:#5C544A;--muted:#928A7C;--line:#E5DCC9;--gold:#B8956A;--gold-deep:#9A754A;--gold-light:#D9BA8E;--navy:#2E4374;--serif:'Fraunces',Georgia,serif;--sans:'Outfit',sans-serif;}
*{margin:0;padding:0;box-sizing:border-box;}html{scroll-behavior:smooth;}
body{background:var(--cream);color:var(--ink);font-family:var(--sans);font-weight:300;line-height:1.65;-webkit-font-smoothing:antialiased;overflow-x:hidden;}
.wrap{max-width:1240px;margin:0 auto;padding:0 32px;}
h1,h2,h3{font-family:var(--serif);font-weight:400;line-height:1.1;}em{font-style:italic;color:var(--gold-deep);}a{color:inherit;text-decoration:none;}
svg.ic{width:100%;height:100%;display:block;}
img.mk{width:auto;height:100%;max-width:100%;object-fit:contain;display:block;}
.bar{background:var(--ink);color:var(--cream);text-align:center;font-size:11px;letter-spacing:.2em;text-transform:uppercase;padding:9px;font-weight:300;}.bar b{color:var(--gold-light);font-weight:400;}
nav{display:flex;align-items:center;justify-content:space-between;padding:20px 32px;border-bottom:1px solid var(--line);position:sticky;top:0;background:rgba(250,246,238,.92);backdrop-filter:blur(10px);z-index:40;}
.logo{font-family:var(--serif);font-size:24px;letter-spacing:.36em;padding-left:.36em;cursor:pointer;}
.nav-links{display:flex;gap:30px;font-size:13px;letter-spacing:.04em;color:var(--ink-soft);}.nav-links a{cursor:pointer;position:relative;transition:color .2s;}.nav-links a:hover{color:var(--ink);}.nav-links .on{color:var(--ink);font-weight:400;}.nav-links .on::after{content:'';position:absolute;left:0;right:0;bottom:-6px;height:1.5px;background:var(--gold);}
.nav-right{display:flex;gap:22px;font-size:13px;color:var(--ink-soft);}
@media(max-width:860px){.nav-links,.nav-right{display:none;}}
.btn{font-family:var(--sans);font-size:13px;letter-spacing:.16em;text-transform:uppercase;padding:16px 32px;cursor:pointer;border:none;transition:all .25s;font-weight:400;display:inline-block;}
.btn-dark{background:var(--ink);color:var(--cream);}.btn-dark:hover{background:var(--gold-deep);}
.btn-out{background:transparent;color:var(--ink);border:1px solid var(--ink);}.btn-out:hover{background:var(--ink);color:var(--cream);}
.rv{opacity:0;transform:translateY(22px);animation:rise .9s cubic-bezier(.2,.7,.2,1) forwards;}@keyframes rise{to{opacity:1;transform:none;}}
section{padding:84px 0;}
.sec-head{text-align:center;max-width:62ch;margin:0 auto 50px;}.sec-head .ek{font-size:12px;letter-spacing:.3em;text-transform:uppercase;color:var(--gold-deep);margin-bottom:16px;}.sec-head h2{font-size:clamp(30px,4.6vw,48px);margin-bottom:14px;}.sec-head p{color:var(--ink-soft);font-size:16px;}
.capbar{background:var(--ink);color:var(--cream);}.capbar .wrap{display:flex;justify-content:space-between;flex-wrap:wrap;gap:16px;padding:20px 32px;}
.cap{display:flex;align-items:center;gap:10px;font-size:12.5px;color:rgba(250,246,238,.85);}.cap .ci{width:21px;height:21px;color:var(--gold-light);flex:none;}
@media(max-width:860px){.capbar .wrap{justify-content:flex-start;}.cap{width:46%;}}
.delhi{display:inline-flex;align-items:center;gap:8px;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--gold-deep);}
.delhi::before{content:'';width:5px;height:5px;border-radius:50%;background:var(--gold);}
footer{background:var(--ink);color:rgba(250,246,238,.6);padding:48px 0;text-align:center;font-size:13px;}
footer .logo{color:var(--cream);margin-bottom:14px;display:inline-block;}footer .fdelhi{color:var(--gold-light);margin:10px 0;letter-spacing:.14em;text-transform:uppercase;font-size:12px;}
.toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--ink);color:var(--cream);padding:14px 26px;border-radius:8px;font-size:14px;opacity:0;pointer-events:none;transition:all .3s;z-index:99;}.toast.show{opacity:1;transform:translateX(-50%);}
.sticky{display:none;position:fixed;bottom:0;left:0;right:0;background:var(--ink);padding:12px 16px;gap:10px;z-index:50;}.sticky button,.sticky a{flex:1;padding:13px;font-size:12px;letter-spacing:.1em;text-transform:uppercase;border:none;cursor:pointer;font-family:var(--sans);text-align:center;text-decoration:none;line-height:1.6;}.sticky .a{background:var(--gold);color:var(--ink);}.sticky .b{background:transparent;color:var(--cream);border:1px solid rgba(250,246,238,.4);}
@media(max-width:860px){.sticky{display:flex;}body{padding-bottom:64px;}}
.hero{position:relative;padding:80px 0 64px;overflow:hidden;}.hero::before{content:'';position:absolute;inset:0;background:radial-gradient(120% 90% at 82% -5%,var(--cream-warm) 0%,transparent 55%),radial-gradient(90% 80% at -5% 105%,#F6E7E9 0%,transparent 50%);z-index:-1;}
.patent-badge{display:inline-flex;align-items:center;gap:9px;border:1px solid var(--gold);color:var(--gold-deep);border-radius:100px;padding:7px 16px 7px 12px;font-size:11px;letter-spacing:.16em;text-transform:uppercase;margin-bottom:24px;}.patent-badge svg{width:15px;height:15px;}
.hero h1{font-size:clamp(42px,7vw,88px);max-width:13ch;margin-bottom:22px;}.hero .lede{font-size:18px;color:var(--ink-soft);max-width:56ch;margin-bottom:32px;}
.cta-row{display:flex;gap:14px;flex-wrap:wrap;align-items:center;}
.hero-strip{display:flex;gap:12px;margin-top:46px;}
.hero-strip .pc{flex:1;background:#fff;border:1px solid var(--line);border-radius:12px;padding:14px 8px 6px;}.hero-strip .pc .imgw{aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;}
.hcap{text-align:center;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-top:6px;}
.lanes{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.lane{border:1px solid var(--line);border-radius:14px;padding:38px;background:#fff;cursor:pointer;transition:all .25s;}.lane:hover{transform:translateY(-4px);box-shadow:0 22px 50px rgba(26,26,26,.10);border-color:var(--gold);}
.lane .li{width:34px;height:34px;color:var(--gold-deep);margin-bottom:16px;}.lane h3{font-size:25px;margin-bottom:10px;}.lane p{color:var(--ink-soft);font-size:15px;margin-bottom:18px;}.lane .go{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--gold-deep);}
@media(max-width:760px){.lanes{grid-template-columns:1fr;}}
.moat{background:var(--cream-warm);}.moat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--line);border:1px solid var(--line);border-radius:16px;overflow:hidden;}
.mcard{background:var(--cream);padding:32px 28px;transition:background .25s;}.mcard:hover{background:#fff;}.mcard .mi{width:32px;height:32px;color:var(--gold-deep);margin-bottom:16px;}.mcard h4{font-family:var(--serif);font-size:20px;margin-bottom:9px;}.mcard p{font-size:14px;color:var(--ink-soft);}.mcard .pill{display:inline-block;margin-top:14px;font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--gold-deep);border:1px solid var(--gold);border-radius:100px;padding:4px 11px;}
@media(max-width:880px){.moat-grid{grid-template-columns:1fr 1fr;}}@media(max-width:560px){.moat-grid{grid-template-columns:1fr;}}
.show-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:18px;}
.show{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px 16px 14px;text-align:center;transition:all .25s;}.show:hover{transform:translateY(-4px);box-shadow:0 18px 40px rgba(26,26,26,.08);}
.show .cw{aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;margin-bottom:10px;}.show .st{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);}
@media(max-width:1024px){.show-grid{grid-template-columns:repeat(3,1fr);}}
@media(max-width:760px){.show-grid{grid-template-columns:1fr 1fr;}}
.occ-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}
.occ{border-radius:14px;overflow:hidden;background:#fff;border:1px solid var(--line);cursor:pointer;transition:all .25s;display:block;}.occ:hover{transform:translateY(-4px);box-shadow:0 22px 50px rgba(26,26,26,.10);}
.occ .ph{aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;position:relative;padding:16px;background:#fff;border-bottom:1px solid var(--line);}.occ .ph .cw{height:100%;display:flex;align-items:center;justify-content:center;}
.occ .bd{padding:22px 24px 26px;}.occ h3{font-size:21px;margin-bottom:7px;}.occ p{font-size:14px;color:var(--ink-soft);margin-bottom:14px;min-height:40px;}.occ .go{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--gold-deep);}
.tag{position:absolute;top:12px;left:12px;background:rgba(26,26,26,.82);color:var(--cream);font-size:10px;letter-spacing:.12em;text-transform:uppercase;padding:4px 10px;border-radius:3px;z-index:2;}
@media(max-width:900px){.occ-grid{grid-template-columns:1fr 1fr;}}@media(max-width:600px){.occ-grid{grid-template-columns:1fr;}}
.ladder-sec{background:var(--ink);color:var(--cream);}.ladder-sec .sec-head h2{color:var(--cream);}.ladder-sec .sec-head .ek{color:var(--gold-light);}.ladder-sec .sec-head p{color:rgba(250,246,238,.6);}
.ladder{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;}.rung{border:1px solid rgba(250,246,238,.18);border-radius:12px;padding:26px 18px;text-align:center;transition:all .25s;}.rung:hover{background:rgba(250,246,238,.05);border-color:var(--gold);}.rung .q{font-size:13px;letter-spacing:.08em;color:rgba(250,246,238,.65);margin-bottom:10px;text-transform:uppercase;}.rung .d{font-family:var(--serif);font-size:34px;color:var(--gold-light);}.rung .n{font-size:12px;color:rgba(250,246,238,.5);margin-top:6px;}
@media(max-width:760px){.ladder{grid-template-columns:1fr 1fr;}.rung:last-child{grid-column:1/-1;}}
.flow{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;position:relative;}.flow::before{content:'';position:absolute;top:34px;left:10%;right:10%;height:1px;background:var(--line);z-index:0;}
.fstep{text-align:center;position:relative;z-index:1;}.fmed{width:68px;height:68px;border-radius:50%;background:var(--cream);border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;transition:all .25s;}.fmed .fi{width:30px;height:30px;color:var(--gold-deep);}.fstep:hover .fmed{background:var(--ink);border-color:var(--ink);}.fstep:hover .fmed .fi{color:var(--gold-light);}.fstep .fn{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;}.fstep h4{font-family:var(--serif);font-size:17px;margin-bottom:6px;}.fstep p{font-size:12.5px;color:var(--ink-soft);}
@media(max-width:760px){.flow{grid-template-columns:1fr 1fr;gap:30px;}.flow::before{display:none;}}
.proof{background:var(--cream-warm);}.logos{display:flex;flex-wrap:wrap;gap:38px;justify-content:center;align-items:center;margin-bottom:46px;}.logos .lg{font-family:var(--serif);font-size:20px;color:var(--ink);opacity:.5;}
.quotes{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;}.qcard{background:#fff;border-radius:12px;padding:28px;border:1px solid var(--line);}.qcard .stars{color:var(--gold);font-size:13px;letter-spacing:3px;margin-bottom:12px;}.qcard p{font-style:italic;font-family:var(--serif);font-size:16px;line-height:1.6;margin-bottom:16px;}.qcard .who{font-size:13px;color:var(--muted);}
@media(max-width:760px){.quotes{grid-template-columns:1fr;}}
.adminhint{font-size:11px;color:var(--muted);text-align:center;margin-top:22px;font-style:italic;}
.qe{background:#fff;border:1px solid var(--line);border-radius:18px;overflow:hidden;display:grid;grid-template-columns:1.15fr .85fr;box-shadow:0 30px 70px rgba(26,26,26,.08);}
.qe-form{padding:46px;}.qe-side{background:var(--ink);color:var(--cream);padding:46px;display:flex;flex-direction:column;}
.qe-form h3{font-size:28px;margin-bottom:6px;}.qe-form .sub{color:var(--ink-soft);font-size:14px;margin-bottom:30px;}
.fld{margin-bottom:24px;}.fld label{display:block;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);margin-bottom:10px;}
.chips{display:flex;flex-wrap:wrap;gap:8px;}.chip{border:1px solid var(--line);background:var(--cream);border-radius:100px;padding:9px 16px;font-size:13px;cursor:pointer;font-family:var(--sans);color:var(--ink-soft);transition:all .18s;}.chip:hover{border-color:var(--ink);}.chip.on{background:var(--ink);color:var(--cream);border-color:var(--ink);}
.qrow{display:flex;align-items:center;gap:16px;}.qrow input[type=range]{flex:1;accent-color:var(--gold-deep);}.qty-num{font-family:var(--serif);font-size:34px;min-width:70px;text-align:right;}
.toggle{display:flex;gap:10px;}.toggle .chip{flex:1;text-align:center;}
.qe-side .lbl{font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:rgba(250,246,238,.55);margin-bottom:6px;}.qe-side .big{font-family:var(--serif);font-size:54px;line-height:1;margin-bottom:4px;}.qe-side .per{font-size:13px;color:rgba(250,246,238,.6);margin-bottom:24px;}
.brk{border-top:1px solid rgba(250,246,238,.16);padding-top:18px;font-size:14px;}.brk .r{display:flex;justify-content:space-between;margin-bottom:9px;color:rgba(250,246,238,.8);}.brk .r.save{color:var(--gold-light);}.brk .r.tot{color:var(--cream);font-family:var(--serif);font-size:20px;border-top:1px solid rgba(250,246,238,.16);padding-top:12px;margin-top:4px;}
.qe-side .note{margin-top:auto;font-size:12px;color:rgba(250,246,238,.5);line-height:1.6;padding-top:22px;}
.qe-cta{background:var(--gold);color:var(--ink);width:100%;margin-top:20px;padding:16px;border:none;font-family:var(--sans);font-size:13px;letter-spacing:.14em;text-transform:uppercase;cursor:pointer;transition:background .2s;font-weight:500;}.qe-cta:hover{background:var(--cream);}
@media(max-width:880px){.qe{grid-template-columns:1fr;}.qe-form,.qe-side{padding:34px;}}
.collab{background:linear-gradient(110deg,var(--navy),#3d5590);color:#fff;border-radius:18px;padding:54px;display:flex;justify-content:space-between;align-items:center;gap:30px;flex-wrap:wrap;}.collab h3{font-size:30px;color:#fff;margin-bottom:8px;}.collab p{color:rgba(255,255,255,.78);max-width:48ch;}.collab .btn-out{color:#fff;border-color:rgba(255,255,255,.6);}.collab .btn-out:hover{background:#fff;color:var(--navy);}
.ohero{padding:70px 0 50px;}.ohero .crumb{font-size:12px;letter-spacing:.1em;color:var(--muted);margin-bottom:18px;}.ohero .crumb a{color:var(--gold-deep);}
.ohero-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:40px;align-items:center;}.ohero h1{font-size:clamp(40px,6vw,72px);margin-bottom:20px;}.ohero p{font-size:17px;color:var(--ink-soft);max-width:50ch;margin-bottom:28px;}
.ohero .hcase{aspect-ratio:1/1;background:#fff;border:1px solid var(--line);border-radius:18px;display:flex;align-items:center;justify-content:center;padding:30px;}
@media(max-width:760px){.ohero-grid{grid-template-columns:1fr;}}
.uc{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;}.uccard{background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden;}.uccard .cw{aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;padding:20px;background:#fff;border-bottom:1px solid var(--line);}.uccard .ucb{padding:22px 24px 26px;}.uccard h4{font-family:var(--serif);font-size:19px;margin-bottom:8px;}.uccard p{font-size:14px;color:var(--ink-soft);}
@media(max-width:760px){.uc{grid-template-columns:1fr;}}
.caseband{background:var(--ink);color:var(--cream);border-radius:18px;padding:50px;}.caseband .ek{color:var(--gold-light);font-size:12px;letter-spacing:.3em;text-transform:uppercase;margin-bottom:14px;}.caseband h3{color:var(--cream);font-size:28px;margin-bottom:14px;max-width:24ch;}.caseband p{color:rgba(250,246,238,.75);max-width:60ch;}
.faqs{max-width:760px;margin:0 auto;}.faq{border-bottom:1px solid var(--line);padding:22px 0;}.faq h4{font-family:var(--serif);font-size:19px;margin-bottom:8px;}.faq p{font-size:15px;color:var(--ink-soft);}
.octa{text-align:center;padding:30px 0;}
.surface-band{background:var(--ink);color:var(--cream);border-radius:18px;padding:50px;display:grid;grid-template-columns:1.08fr .92fr;gap:42px;align-items:center;}
.surface-band .ek{color:var(--gold-light);font-size:12px;letter-spacing:.3em;text-transform:uppercase;margin-bottom:14px;}
.surface-band h3{color:var(--cream);font-size:clamp(26px,3.6vw,34px);margin-bottom:14px;max-width:18ch;}
.surface-band p{color:rgba(250,246,238,.76);margin-bottom:26px;max-width:50ch;}
.surface-band .sb-art{aspect-ratio:1/1;background:#fff;border-radius:14px;display:flex;align-items:center;justify-content:center;padding:26px;}
.surface-band .sb-art .mk{height:100%;}
.surface-band .btn-out{color:var(--cream);border-color:rgba(250,246,238,.55);}.surface-band .btn-out:hover{background:var(--cream);color:var(--ink);border-color:var(--cream);}
@media(max-width:760px){.surface-band{grid-template-columns:1fr;padding:34px;}}
.promise{background:var(--cream-warm);border:1px solid var(--line);border-radius:18px;padding:52px;}
.promise .pr-head{display:flex;align-items:center;gap:18px;margin-bottom:16px;}
.promise .pi{width:56px;height:56px;flex:none;border-radius:50%;border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;color:var(--gold-deep);background:#fff;}.promise .pi svg{width:26px;height:26px;}
.promise .ek{font-size:12px;letter-spacing:.3em;text-transform:uppercase;color:var(--gold-deep);margin-bottom:6px;}
.promise h2{font-size:clamp(26px,4vw,40px);}
.promise .pr-lede{color:var(--ink-soft);font-size:16px;max-width:74ch;margin-bottom:34px;}
.promise .pr-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;}
.promise .prs{background:#fff;border:1px solid var(--line);border-radius:12px;padding:26px;}
.promise .prn{font-family:var(--serif);font-size:24px;color:var(--gold);display:block;margin-bottom:10px;}
.promise .prs h4{font-family:var(--serif);font-size:18px;margin-bottom:7px;}.promise .prs p{font-size:14px;color:var(--ink-soft);}
@media(max-width:760px){.promise{padding:32px;}.promise .pr-steps{grid-template-columns:1fr;}}
.pmini{display:inline-flex;align-items:center;gap:9px;font-size:13.5px;color:var(--ink-soft);margin-top:16px;}.pmini svg{width:17px;height:17px;color:var(--gold-deep);flex:none;}
.who-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;}
.who{background:#fff;border:1px solid var(--line);border-radius:14px;padding:28px;transition:all .25s;}.who:hover{transform:translateY(-4px);box-shadow:0 18px 40px rgba(26,26,26,.08);}
.who .wi{width:30px;height:30px;color:var(--gold-deep);margin-bottom:14px;}.who h4{font-family:var(--serif);font-size:18px;margin-bottom:8px;}.who p{font-size:13.5px;color:var(--ink-soft);}
@media(max-width:900px){.who-grid{grid-template-columns:1fr 1fr;}}@media(max-width:520px){.who-grid{grid-template-columns:1fr;}}
.tiers{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;align-items:stretch;}
.tier{border:1px solid var(--line);border-radius:16px;background:#fff;padding:36px 32px;display:flex;flex-direction:column;}
.tier.feat{background:var(--ink);color:var(--cream);border-color:var(--ink);}
.tier .tname{font-family:var(--serif);font-size:24px;margin-bottom:6px;}
.tier .tfor{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-bottom:20px;}.tier.feat .tfor{color:var(--gold-light);}
.tier .trate{font-family:var(--serif);font-size:42px;color:var(--gold-deep);line-height:1;}.tier.feat .trate{color:var(--gold-light);}
.tier .trate small{font-family:var(--sans);font-size:13px;color:var(--muted);letter-spacing:.04em;}.tier.feat .trate small{color:rgba(250,246,238,.6);}
.tier .tearn{font-family:var(--serif);font-size:19px;color:var(--gold-deep);line-height:1.45;min-height:54px;}.tier.feat .tearn{color:var(--gold-light);}
.tier ul{list-style:none;margin:22px 0 26px;}.tier li{font-size:14px;color:var(--ink-soft);padding:11px 0 11px 26px;position:relative;border-top:1px solid var(--line);}.tier.feat li{color:rgba(250,246,238,.82);border-color:rgba(250,246,238,.14);}
.tier li::before{content:'';position:absolute;left:0;top:16px;width:8px;height:8px;border:1.5px solid var(--gold);border-radius:50%;}
.tier .btn{margin-top:auto;text-align:center;}
.tier.feat .btn-out{color:var(--cream);border-color:rgba(250,246,238,.5);}.tier.feat .btn-out:hover{background:var(--cream);color:var(--ink);}
.tier .tbadge{display:inline-block;align-self:flex-start;font-size:10px;letter-spacing:.14em;text-transform:uppercase;background:var(--gold);color:var(--ink);border-radius:100px;padding:4px 12px;margin-bottom:14px;}
@media(max-width:880px){.tiers{grid-template-columns:1fr;}}
.perks{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;}
.perk{display:flex;gap:13px;align-items:flex-start;background:#fff;border:1px solid var(--line);border-radius:12px;padding:22px;}
.perk .pk{width:22px;height:22px;color:var(--gold-deep);flex:none;margin-top:2px;}.perk h5{font-size:15px;font-family:var(--serif);margin-bottom:3px;}.perk p{font-size:13px;color:var(--ink-soft);}
@media(max-width:760px){.perks{grid-template-columns:1fr;}}
.pstrip{background:linear-gradient(110deg,var(--navy),#3d5590);color:#fff;border-radius:18px;padding:46px;display:flex;justify-content:space-between;align-items:center;gap:24px;flex-wrap:wrap;}.pstrip h3{font-size:26px;color:#fff;margin-bottom:6px;}.pstrip p{color:rgba(255,255,255,.8);max-width:48ch;}.pstrip .btn-out{color:#fff;border-color:rgba(255,255,255,.6);}.pstrip .btn-out:hover{background:#fff;color:var(--navy);}
.sizes-band{background:var(--cream-warm);border-top:1px solid var(--line);border-bottom:1px solid var(--line);}
.sizes-band .wrap{display:grid;grid-template-columns:repeat(4,1fr);gap:0;}
.sizes-band .sz{text-align:center;padding:30px 18px;border-right:1px solid var(--line);}.sizes-band .sz:last-child{border-right:none;}
.sizes-band .szn{font-family:var(--serif);font-size:22px;}.sizes-band .szi{font-size:13px;color:var(--gold-deep);letter-spacing:.06em;margin:3px 0 8px;}.sizes-band .szd{font-size:12.5px;color:var(--ink-soft);}
@media(max-width:760px){.sizes-band .wrap{grid-template-columns:1fr 1fr;}.sizes-band .sz:nth-child(2){border-right:none;}.sizes-band .sz:nth-child(1),.sizes-band .sz:nth-child(2){border-bottom:1px solid var(--line);}}
.bundle-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;}
.bundle{background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden;display:flex;flex-direction:column;transition:all .25s;}.bundle:hover{transform:translateY(-4px);box-shadow:0 22px 50px rgba(26,26,26,.10);}
.bundle .bph{aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;padding:18px;border-bottom:1px solid var(--line);background:#fff;}
.bundle .bbd{padding:22px 22px 24px;display:flex;flex-direction:column;flex:1;}
.bundle h4{font-family:var(--serif);font-size:19px;margin-bottom:8px;}.bundle .bin{font-size:13.5px;color:var(--ink-soft);margin-bottom:16px;flex:1;}
.bundle .bprice{font-family:var(--serif);font-size:24px;}.bundle .bsave{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--gold-deep);margin:3px 0 16px;}
.bundle .go{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--gold-deep);}
@media(max-width:1000px){.bundle-grid{grid-template-columns:1fr 1fr;}}@media(max-width:560px){.bundle-grid{grid-template-columns:1fr;}}
'''

NAV='''<div class="bar">India's <b>only patented</b> personalised luggage maker · ships to US · UK · Canada in 2–7 days</div>
<nav><div class="logo" onclick="location.href='amairee-gifting-hub-mockup.html'">AMAIREE</div>
<div class="nav-links"><a href="amairee-gifting-hub-mockup.html#occasions">Shop</a><a>Design Your Own</a><a class="on" href="amairee-gifting-hub-mockup.html">Gifting</a><a>Gift Cards</a></div>
<div class="nav-right"><a>Account</a><a>Cart</a></div></nav>'''
def FOOTER():
    return '<footer><div class="wrap"><div class="logo">AMAIREE</div><div class="fdelhi">Made in Delhi, India</div><div>Ships to India, US, UK &amp; Canada in 2–7 days · amairee.com · +91 99111 12624 · @amaireeofficial</div></div></footer>'
def HEAD(t):
    return ('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>'+t+'</title>'
      '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
      '<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Outfit:wght@200;300;400;500;600&display=swap" rel="stylesheet"><style>'+CSS+'</style></head><body>')
print("css/nav/head ready")

OCC=[
 {"slug":"weddings","title":"Weddings","tag":"Most loved","face":('D_MIDNIGHT','Anderson','mrmrs','large'),
  "h1":"A keepsake for <em>every guest.</em>","sub":"Camera-ready honeymoon sets for the couple, named pieces for the party, and keepsakes for every guest — easy to split across a registry, and used for years rather than tossed after the function.",
  "uc":[("Bride & groom set","A camera-ready, matching pair for the honeymoon — Mr & Mrs, Hubby & Wifey, or your monogram and wedding date.",('D_MIDNIGHT','WIFEY|12.04.26','est','large')),("Bridal party","Coordinated pieces — Bride, Bridesmaid, Team Bride — each with their own name.",('D_BLUSH_FLORAL','BRIDE','block','medium')),("Guest return gifts","Personalised in bulk for every invitee — and easy for friends and family to group-gift on the registry.",('D_SAGE_MARBLE','Aanya','name','cabin'))],
  "band":'<section class="wrap" style="padding-top:0;"><div class="sec-head"><div class="ek">Wedding looks</div><h2>Looks our couples <em>love.</em></h2><p>A starting point, not a limit — bring your own palette, monogram or invite and our studio designs the rest.</p></div><div class="show-grid">'+show_tiles([('Bride','D_BLUSH_FLORAL','BRIDE','block','large'),('Bride to be','D_BUTTER_CREAM','Bride to be','script','large'),('Mr & Mrs','D_MIDNIGHT','Anderson','mrmrs','medium'),('Hubby & Wifey','D_MIDNIGHT','WIFEY|12.04.26','est','cabin'),('The surname','D_MIDNIGHT','MRS|Johnson|EST 2026','bigname','medium')])+'</div></section>',
  "case":("80 pieces for the Sharma wedding — in 12 days","Matching cabin cases for the couple, named pieces for the bridal party, and personalised return gifts for sixty guests — designed, produced and QC'd in our atelier, delivered three days before the sangeet."),
  "faq":[("Can every piece have a different name?","Yes — each unit is personalised individually, whether it's two or two hundred."),("How far ahead should we order?","3–4 weeks is ideal for large weddings; we hold stock, so rush is often possible."),("Can you match our wedding colours?","Our in-house designers match your palette, monogram and invite motif.")]},
 {"slug":"corporate","title":"Corporate","tag":"Bulk","face":('D_MIDNIGHT','Northwind','surface','large'),
  "h1":"Gifts your team will <em>brag about.</em>","sub":"More memorable than another notebook or pen — branded with your logo, named for each person, and seen everywhere your team travels. Onboarding kits, client gifting and rewards, delivered without a logistics headache.",
  "band":'<section class="wrap" style="padding-top:0;"><div class="surface-band"><div class="sb-copy"><div class="ek">New &middot; full-surface</div><h3>Make the <em>whole case</em> your brand.</h3><p>Not just a logo in the corner. Sublimate your brand across the entire shell &mdash; edge-to-edge colour, your logo, your launch artwork. The boldest branded gift in the room, and the one people actually keep using.</p><a class="btn btn-out" href="amairee-gifting-hub-mockup.html#quote">Brief a full-surface run &rarr;</a></div><div class="sb-art">'+MK('D_MIDNIGHT','Northwind','surface','large')+'</div></div></section>',
  "uc":[("Onboarding kits","A personalised piece with each joiner's name and your logo — a welcome they'll actually use.",('D_BUTTER_CREAM','Northwind','logo','cabin')),("Client gifting","Premium branded gifts that keep your name in view long after the meeting ends.",('D_NAVY_MARBLE','Lumen','logo','medium')),("Rewards & festive","Diwali hampers and recognition gifts that beat generic swag — and last for years.",('D_GOLD_MONOGRAM','Diwali','name','cabin'))],
  "case":("200 onboarding kits, one WhatsApp thread","A fast-growing SaaS firm gifts every new joiner a personalised case with their name and the company mark — reordered every quarter, near-zero effort."),
  "faq":[("Can you print our company logo?","Yes — logo branding from MOQ 25, with a proof before production."),("GST invoicing and credit terms?","GST invoicing as standard; NET terms for corporate accounts above a threshold."),("Can we set up a reorder account?","Yes — a named account with saved addresses and 2-tap reorders.")]},
 {"slug":"events","title":"Events & Conferences","tag":"","face":('D_SAGE_MARBLE','Summit','logo','medium'),
  "h1":"On-brand bags, <em>delivered on time.</em>","sub":"Branded attendee bags and summit kits that outlast the lanyard — bulk, on-brand, and reliably on schedule for the day that matters.",
  "uc":[("Attendee bags","Branded, personalised pieces guests keep using — not forgettable tote-bag swag.",('D_SAGE_MARBLE','Summit','logo','cabin')),("Offsite kits","Team-trip kits with each person's name — instant group identity on the road.",('D_NAVY_MARBLE','Offsite','name','medium')),("Speaker & VIP gifts","Elevated pieces that thank speakers and sponsors in style.",('D_GOLD_MONOGRAM','VIP','logo','large'))],
  "case":("Conference for 300 — kitted and delivered","Personalised attendee bags for a national summit, produced and QC'd in-house and delivered to the venue the day before doors opened."),
  "faq":[("Lead time for events?","10–15 days standard; rush often possible from ready stock."),("Deliver to the venue?","Yes — pan-India, and to the US, UK and Canada in 2–7 days."),("Different name on each bag?","Yes — individual personalisation at any volume.")]},
 {"slug":"brand-launch","title":"Brand Launch & PR","tag":"","face":('D_GOLD_MONOGRAM','Brand','logo','medium'),
  "h1":"Built for the <em>unboxing.</em>","sub":"Influencer and press kits made to be opened on camera — a co-branded, personalised piece people keep, and keep posting.",
  "uc":[("Influencer kits","Personalised pieces creators want to film, keep and travel with.",('D_BLUSH_FLORAL','Maya','name','cabin')),("Press kits","Polished, branded kits for launch-day press.",('D_NAVY_MARBLE','Press','logo','medium')),("Seeding at scale","Hundreds of named kits, QC'd in-house.",('D_GOLD_MONOGRAM','Brand','logo','cabin'))],
  "case":("A launch that seeded itself","Co-branded personalised kits sent to 120 creators — the named, made-to-keep piece drove organic unboxing content for weeks."),
  "faq":[("Co-brand with our logo and Amairee?","Yes — co-branded layouts designed in-house, proofed before production."),("Personalise each kit to the recipient?","Yes — name or handle on every piece."),("How fast can a launch go out?","With stock on hand we move quickly on launch timelines.")]},
 {"slug":"parties","title":"Parties","tag":"","face":('D_LAVENDER','Sara','name','kids'),
  "h1":"Favours they'll <em>actually keep.</em>","sub":"Milestone birthdays, anniversaries and kids' return favours — high-utility keepsakes guests keep, not disposable party bags. For groups, everyone's instantly recognisable at the airport.",
  "uc":[("Kids' return favours","Mini personalised cases with each child's name — no more mix-ups at school, camp or sleepovers.",('D_TROPICAL','Kabir','name','kids')),("Milestone birthdays","A bold, personal piece for the big ones — their name front and centre.",('D_CHERRY','SARA','block','medium')),("Anniversaries","His-and-hers monogrammed pieces to mark the years together.",('D_BUTTER_CREAM','A M','monogram','large'))],
  "case":("A first birthday, 30 little keepsakes","Mini personalised pieces with every child's name — the return favour parents messaged about for weeks."),
  "faq":[("Minimum for party favours?","Personalised bulk starts at 10 pieces."),("Can small pieces be personalised?","Yes — pouches and tags carry names and motifs too."),("How quickly can party orders ship?","10–15 days standard, often faster from ready stock.")]},
 {"slug":"collaborations","title":"Brand Collaborations","tag":"","face":('D_NAVY_MARBLE','Amairee','logo','large'),
  "h1":"Co-create a <em>capsule.</em>","sub":"A patented, personalised product and a shared audience. We partner with thoughtful brands on co-branded capsules — co-design, co-market, share the win.",
  "uc":[("Co-branded capsule","A limited Amairee × You edition, designed together.",('D_NAVY_MARBLE','Amairee','logo','large')),("Shared audiences","Reach each other's customers with a keepable product.",('D_OCEAN_TIDE','Brand','logo','medium')),("Made entirely in-house","Design, production and QC under one roof.",('D_MIDNIGHT','Capsule','name','cabin'))],
  "case":("Amairee × a brand we admire","A co-branded, personalised capsule — co-designed in our studio, co-marketed to both audiences, produced and QC'd in-house."),
  "faq":[("What collaboration models?","Co-branding, revenue share and exclusivity — structured to fit."),("Who designs the capsule?","Our in-house studio, with your team."),("Is the product protected?","Yes — patented personalisation; we're the only manufacturer in India.")]},
]

REDESIGN_FAQ=("What if the design no longer fits — can it be changed later?","Yes — it's our Redesign Promise. Any Amairee piece can return to our studio to be re-skinned with a brand-new design for &#8377;1,200&ndash;2,000 depending on size, so a personalised gift is never wasted.")
for _o in OCC: _o["faq"]=_o["faq"]+[REDESIGN_FAQ]

MOAT=[('seal','Patented &amp; protected','Our personalisation method is patented — a product no competitor in India can legally replicate.','Patented'),('factory',"India's only manufacturer","Not a reseller, not an importer. We are the single manufacturer of this product in the country.",'Sole maker'),('pen','In-house designers','Our own studio creates every artwork, monogram and layout — bespoke to your occasion or brand.','In-house'),('gear','In-house production','Built in our own atelier, not outsourced. Full control of timeline, finish and consistency.','In-house'),('qc','In-house quality control','Every single unit is inspected by hand before it ships. Quality isn\'t a step — it\'s the point.','Every unit'),('boxes','Any number, always ready','We hold bulk stock year-round and can supply any quantity — five pieces or five thousand.','Unlimited'),('mono','Anything in personalisation','Names, dates, monograms, logos, full artworks — if you can imagine it, we can put it on the piece.','Limitless'),('globe','Worldwide delivery','Ships to India, the US, UK and Canada in 2–7 days — personalised gifts, anywhere.','US · UK · CA'),('shield','Quality is the key','One ethos in every order: a personal touch in each unit made. That\'s why buyers return.','Our promise')]

# ---- HUB ----
hero=[('Aanya','D_ROSE_MARBLE'),('Karan','D_NAVY_MARBLE'),('Riya','D_SAGE_MARBLE'),('Dev','D_BUTTER_CREAM'),('Sara','D_LAVENDER')]
hero_strip=''.join('<div class="pc"><div class="imgw">'+MK(d,n)+'</div><div class="hcap">'+n+'</div></div>' for n,d in hero)
show=[('Their name','D_ROSE_MARBLE','Aanya','name','cabin'),('Your logo','D_BUTTER_CREAM','Northwind','logo','medium'),('A wedding invite','D_SAGE_MARBLE','R K','invite','large'),('A monogram','D_LAVENDER','A M','monogram','cabin'),('Your whole brand','D_MIDNIGHT','Your Logo','surface','medium')]
show_grid=''.join('<div class="show"><div class="cw">'+MK(d,t,k,s)+'</div><div class="st">'+lbl+'</div></div>' for lbl,d,t,k,s in show)
occ_cards=''
for o in OCC:
    tag='<span class="tag">'+o["tag"]+'</span>' if o["tag"] else ''
    occ_cards+=('<a class="occ" href="amairee-gifting-'+o["slug"]+'.html"><div class="ph">'+tag+'<div class="cw">'+MK(*o["face"])+'</div></div><div class="bd"><h3>'+o["title"]+'</h3><p>'+o["sub"][:84]+'…</p><span class="go">Explore '+o["title"]+' &rarr;</span></div></a>')
moat_cards=''.join('<div class="mcard"><div class="mi">'+I(ic)+'</div><h4>'+h+'</h4><p>'+p+'</p><span class="pill">'+pl+'</span></div>' for ic,h,p,pl in MOAT)

SIZES='<div class="sizes-band"><div class="wrap"><div class="sz"><div class="szn">Kids</div><div class="szi">16&Prime;</div><div class="szd">Mini cases &amp; return favours</div></div><div class="sz"><div class="szn">Cabin</div><div class="szi">20&Prime;</div><div class="szd">Carry-on &amp; honeymoon pairs</div></div><div class="sz"><div class="szn">Medium</div><div class="szi">24&Prime;</div><div class="szd">The everyday traveller</div></div><div class="sz"><div class="szn">Large</div><div class="szi">28&Prime;</div><div class="szd">Big trips &amp; full sets</div></div></div></div>'

BUNDLES=[
 ("Honeymoon Set","A matching Cabin pair — Mr &amp; Mrs, Hubby &amp; Wifey, or your monogram and date. Camera-ready for the first trip.","From &#8377;16,500","Save &#8377;1,500 vs singly",('D_MIDNIGHT','Anderson','mrmrs','cabin'),"amairee-gifting-weddings.html"),
 ("Bridal Party Set","Six coordinated pieces — Bride, Bridesmaid, Team Bride — each with their own name.","From &#8377;49,900","6 pieces · save &#8377;4,100",('D_BLUSH_FLORAL','BRIDE','block','cabin'),"amairee-gifting-weddings.html"),
 ("Kids' Party Pack","Ten mini cases for return favours, each personalised with a child's name — no school mix-ups.","From &#8377;64,900","10 pieces · save &#8377;10,100",('D_TROPICAL','Kabir','name','kids'),"amairee-gifting-parties.html"),
 ("Corporate Onboarding Kit","Branded, named pieces for new joiners — order from ten and reorder in two taps.","From &#8377;8,100 / piece","Min 10 · branding included",('D_NAVY_MARBLE','Northwind','logo','cabin'),"amairee-gifting-corporate.html"),
]
bundle_cards=''.join('<a class="bundle" href="'+lnk+'"><div class="bph">'+MK(*face)+'</div><div class="bbd"><h4>'+nm+'</h4><div class="bin">'+inside+'</div><div class="bprice">'+price+'</div><div class="bsave">'+sub+'</div><span class="go">Build this set &rarr;</span></div></a>' for nm,inside,price,sub,face,lnk in BUNDLES)

HUB=HEAD('Amairee · Gifting & Bulk — concept')+NAV+'''
<header class="hero"><div class="wrap"><div class="patent-badge rv">'''+I('seal')+'''Patented · India's only manufacturer</div>
<h1 class="rv" style="animation-delay:.06s">Gifts no one else <em>can make.</em></h1>
<p class="lede rv" style="animation-delay:.14s">A patented, personalised piece — designed, built and quality-checked entirely in our own atelier in Delhi. From a single thoughtful gift to five thousand, every unit carries a name, and not one leaves without our hands on it.</p>
<div class="cta-row rv" style="animation-delay:.22s"><button class="btn btn-dark" onclick="scrollTo2('occasions')">Browse occasions</button><button class="btn btn-out" onclick="scrollTo2('quote')">Get a bulk quote</button><span class="delhi">Made in Delhi, India</span></div>
<div class="hero-strip rv" style="animation-delay:.32s">'''+hero_strip+'''</div></div></header>
<div class="capbar"><div class="wrap"><div class="cap"><span class="ci">'''+I('seal')+'''</span>Patented design</div><div class="cap"><span class="ci">'''+I('factory')+'''</span>Only maker in India</div><div class="cap"><span class="ci">'''+I('boxes')+'''</span>Any volume, in stock</div><div class="cap"><span class="ci">'''+I('globe')+'''</span>US · UK · CA in 2–7 days</div><div class="cap"><span class="ci">'''+I('qc')+'''</span>In-house QC on every unit</div></div></div>'''+SIZES+'''
<section class="wrap" style="padding-top:60px;"><div class="lanes"><div class="lane" onclick="scrollTo2('occasions')"><div class="li">'''+I('gift')+'''</div><h3>I'm gifting someone</h3><p>Pick an occasion, add their name, and we'll make a single piece they'll treasure — or up to ten, ready to ship.</p><span class="go">Browse occasions &rarr;</span></div><div class="lane" onclick="scrollTo2('quote')"><div class="li">'''+I('boxes')+'''</div><h3>I'm ordering in bulk</h3><p>Weddings, teams, events — any quantity. A dedicated manager quotes within 24 hours.</p><span class="go">Get a bulk quote &rarr;</span></div></div></section>
<section class="moat"><div class="wrap"><div class="sec-head"><div class="ek">Why Amairee</div><h2>A product the rest <em>simply can't make.</em></h2><p>Our personalisation is patented and our craft is entirely our own — every stage under one roof, every unit touched by hand.</p></div><div class="moat-grid">'''+moat_cards+'''</div></div></section>
<section class="wrap"><div class="sec-head"><div class="ek">Personalisation</div><h2>Put <em>anything</em> on it.</h2><p>A name, your company logo, a wedding invite, a monogram — or go bolder and sublimate your brand across the entire shell. Our in-house studio prints it onto every piece. (On the live site these examples are managed from the admin panel.)</p></div><div class="show-grid">'''+show_grid+'''</div></section>
<section class="wrap" style="padding-top:0;"><div class="promise"><div class="pr-head"><div class="pi">'''+I('refresh')+'''</div><div><div class="ek">The Redesign Promise</div><h2>A gift that's <em>never wasted.</em></h2></div></div><p class="pr-lede">Names change. Tastes change. Life changes. Any Amairee piece can come back to our studio to be re-skinned with a brand-new design — a modest fee of &#8377;1,200&ndash;2,000 depending on size. So a personalised gift never sits unused in a cupboard. It simply becomes its next chapter.</p><div class="pr-steps"><div class="prs"><span class="prn">01</span><h4>Gift it personalised</h4><p>Their name, your logo, your artwork — made to feel like theirs from day one.</p></div><div class="prs"><span class="prn">02</span><h4>Travel for years</h4><p>Built by hand to be used, not stored away — quality you keep reaching for.</p></div><div class="prs"><span class="prn">03</span><h4>Refresh anytime</h4><p>Send it back and we re-skin it with a new design — &#8377;1,200&ndash;2,000 depending on size.</p></div></div></div></section>
<section id="occasions" class="wrap"><div class="sec-head"><div class="ek">Occasions</div><h2>One brief. <em>Every occasion.</em></h2><p>However many you need, every piece carries a name. Tap an occasion to explore.</p></div><div class="occ-grid">'''+occ_cards+'''</div></section>
<section class="wrap"><div class="sec-head"><div class="ek">Gift sets</div><h2>Ready-made <em>gift sets.</em></h2><p>Curated packages that take the guesswork out — matched designs, set pricing, and a saving versus buying singly. You personalise the names; we do the rest.</p></div><div class="bundle-grid">'''+bundle_cards+'''</div></section>
<section class="ladder-sec"><div class="wrap"><div class="sec-head"><div class="ek">Bulk pricing</div><h2>Order more, <em>save more.</em></h2><p>Volume pricing with personalisation included at every tier — stock ready to go.</p></div><div class="ladder"><div class="rung"><div class="q">5&ndash;9</div><div class="d">5%</div><div class="n">off</div></div><div class="rung"><div class="q">10&ndash;24</div><div class="d">10%</div><div class="n">off</div></div><div class="rung"><div class="q">25&ndash;49</div><div class="d">15%</div><div class="n">off</div></div><div class="rung"><div class="q">50&ndash;99</div><div class="d">20%</div><div class="n">off + free names</div></div><div class="rung"><div class="q">100+</div><div class="d">Let's talk</div><div class="n">custom + account manager</div></div></div></div></section>
<section id="quote" class="wrap"><div class="sec-head"><div class="ek">Bulk enquiry</div><h2>Build your <em>bulk quote</em></h2><p>Adjust the details and see indicative pricing instantly. We confirm — with stock and a print proof — within 24 hours.</p></div>
<div class="qe"><div class="qe-form"><h3>Tell us what you're planning</h3><div class="sub">Indicative only — final quote confirmed by your gifting manager.</div>
<div class="fld"><label>Occasion</label><div class="chips" id="occChips"><div class="chip on" data-occ="Wedding">Wedding</div><div class="chip" data-occ="Corporate gifting">Corporate</div><div class="chip" data-occ="Event / conference">Event</div><div class="chip" data-occ="Brand launch / PR">Brand launch</div><div class="chip" data-occ="Party / return favours">Party</div><div class="chip" data-occ="Custom">Custom</div></div></div>
<div class="fld"><label>Piece</label><div class="chips" id="prodChips"><div class="chip" data-base="7500">Kids 16"</div><div class="chip on" data-base="9000">Cabin 20"</div><div class="chip" data-base="11000">Medium 24"</div><div class="chip" data-base="13000">Large 28"</div><div class="chip" data-base="2500">Pouch / tag</div></div></div>
<div class="fld"><label>Quantity &mdash; <span id="qtyTier">10% off</span></label><div class="qrow"><input type="range" id="qtyRange" min="1" max="500" value="40" oninput="syncQty(this.value)"><span class="qty-num" id="qtyNum">40</span></div></div>
<div class="fld"><label>Gift presentation</label><div class="toggle" id="boxChips"><div class="chip on" data-box="0">Standard</div><div class="chip" data-box="250">Signature +&#8377;250</div><div class="chip" data-box="600">Luxe +&#8377;600</div></div></div>
<div class="fld" style="margin-bottom:0;"><label>Timeline</label><div class="chips" id="timeChips"><div class="chip on" data-time="Standard (10–15 days)">10&ndash;15 days</div><div class="chip" data-time="Rush (under 10 days)">Rush</div><div class="chip" data-time="Flexible">Flexible</div></div></div></div>
<div class="qe-side"><div class="lbl">Indicative total</div><div class="big" id="totBig">&#8377;3,24,000</div><div class="per" id="perUnit">&#8377;8,100 / piece · 40 pieces</div><div class="brk"><div class="r"><span>List price</span><span id="brkList">&#8377;3,60,000</span></div><div class="r save"><span id="brkDiscLbl">Volume discount (10%)</span><span id="brkDisc">&ndash; &#8377;36,000</span></div><div class="r"><span>Personalisation</span><span>Included</span></div><div class="r"><span>Gift presentation</span><span id="brkBox">Standard</span></div><div class="r tot"><span>Total</span><span id="brkTot">&#8377;3,24,000</span></div></div><button class="qe-cta" onclick="sendQuote()">Get this quote on WhatsApp &rarr;</button><div class="note" id="qeNote">In stock now — print proof and final pricing within 24 hours. Ships to US · UK · CA in 2–7 days.</div></div></div></section>
<section class="wrap" style="padding-top:0;"><div class="sec-head"><div class="ek">The process</div><h2>From brief to doorstep, <em>under one roof.</em></h2></div><div class="flow"><div class="fstep"><div class="fmed"><span class="fi">'''+I('brief')+'''</span></div><div class="fn">Step one</div><h4>Brief</h4><p>Share the occasion, quantity and timeline.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('pen')+'''</span></div><div class="fn">Step two</div><h4>Design</h4><p>Our studio sends mockups &amp; a quote in 24 hrs.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('gear')+'''</span></div><div class="fn">Step three</div><h4>Produce</h4><p>Built by hand in our own atelier.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('qc')+'''</span></div><div class="fn">Step four</div><h4>Quality check</h4><p>Every unit inspected before it ships.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('truck')+'''</span></div><div class="fn">Step five</div><h4>Deliver</h4><p>Pan-India &amp; to US · UK · CA in 2–7 days.</p></div></div></section>
<section class="proof"><div class="wrap"><div class="sec-head"><div class="ek">Trusted by</div><h2>Brands &amp; couples <em>who chose us.</em></h2></div><div class="logos" id="logoWall"></div><div class="quotes" id="reviewWall"></div><div class="adminhint">Client logos and reviews shown here are managed from the Amairee admin panel.</div></div></section>
<section class="wrap"><div class="collab"><div><h3>Co-create a capsule with Amairee</h3><p>A patented, personalised product and a shared audience. We partner with thoughtful brands on co-branded capsules — co-design, co-market, share the win.</p></div><a class="btn btn-out" href="amairee-gifting-collaborations.html">Explore collaborations &rarr;</a></div></section>
<section class="wrap" style="padding-top:0;"><div class="pstrip"><div><h3>Earn with Amairee — join the Partner Program</h3><p>Creators, planners and happy customers earn commission on every order they send our way — plus free pieces, your own code and real payouts.</p></div><a class="btn btn-out" href="amairee-gifting-ambassador.html">Become a partner &rarr;</a></div></section>
'''+FOOTER()+'''
<div class="sticky"><button class="b" onclick="scrollTo2('occasions')">Browse</button><button class="a" onclick="scrollTo2('quote')">Get a quote</button></div><div class="toast" id="toast"></div>
<script>
function scrollTo2(id){document.getElementById(id).scrollIntoView({behavior:'smooth'});}
let tT;function toast(t,m){const e=document.getElementById('toast');e.textContent=m?(t+' — '+m):t;e.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>e.classList.remove('show'),3200);}
const LOGOS=["Northwind","Lumen Co.","Saffron HR","Vega Labs","The Wedding Edit","Mehta & Sons"];
const REVIEWS=[{s:5,t:"We gifted 60 onboarding kits — every new joiner posted theirs on LinkedIn. Best employer-brand spend of the year.",w:"Head of People · SaaS company"},{s:5,t:"You can tell it's made by hand. The finish on 80 pieces was identical — and on time.",w:"Wedding planner · Delhi"},{s:5,t:"One WhatsApp, one manager, 200 pieces delivered on time. That never happens.",w:"Admin Lead · Consulting firm"}];
document.getElementById('logoWall').innerHTML=LOGOS.map(l=>`<span class="lg">${l}</span>`).join('');
document.getElementById('reviewWall').innerHTML=REVIEWS.map(r=>`<div class="qcard"><div class="stars">${'★'.repeat(r.s)}</div><p>"${r.t}"</p><div class="who">${r.w}</div></div>`).join('');
const state={occ:'Wedding',base:9000,qty:40,box:0,time:'Standard (10–15 days)'};
function tierFor(q){if(q>=100)return{pct:null,lbl:"Let's talk"};if(q>=50)return{pct:.20,lbl:'20% off'};if(q>=25)return{pct:.15,lbl:'15% off'};if(q>=10)return{pct:.10,lbl:'10% off'};if(q>=5)return{pct:.05,lbl:'5% off'};return{pct:0,lbl:'No bulk discount yet'};}
const fmt=n=>'\u20B9'+Math.round(n).toLocaleString('en-IN');
function prodName(){const e=document.querySelector('#prodChips .chip.on');return e?e.textContent:'Cabin 20"';}
function recalc(){const q=state.qty,t=tierFor(q),u=state.base+state.box;document.getElementById('qtyTier').textContent=t.lbl;const bn=state.box===0?'Standard':state.box===250?'Signature (+\u20B9250)':'Luxe (+\u20B9600)';document.getElementById('brkBox').textContent=bn;
 if(t.pct===null){document.getElementById('totBig').textContent="Let's talk";document.getElementById('perUnit').textContent=q+' pieces · custom pricing + account manager';document.getElementById('brkList').textContent=fmt(u*q);document.getElementById('brkDiscLbl').textContent='Volume (100+)';document.getElementById('brkDisc').textContent='custom';document.getElementById('brkTot').textContent="Let's talk";}
 else{const L=u*q,d=L*t.pct,T=L-d;document.getElementById('totBig').textContent=fmt(T);document.getElementById('perUnit').textContent=fmt(T/q)+' / piece · '+q+' pieces';document.getElementById('brkList').textContent=fmt(L);document.getElementById('brkDiscLbl').textContent='Volume discount ('+Math.round(t.pct*100)+'%)';document.getElementById('brkDisc').textContent=t.pct?'\u2013 '+fmt(d):'\u2014';document.getElementById('brkTot').textContent=fmt(T);}
 document.getElementById('qeNote').textContent=`${state.occ} · ${prodName()} · ${q} pieces · ${state.time}. In stock now — proof + final pricing in 24 hrs. Ships to US · UK · CA in 2–7 days.`;}
function syncQty(v){state.qty=parseInt(v,10);document.getElementById('qtyNum').textContent=v;recalc();}
function bind(id,k,p){document.querySelectorAll('#'+id+' .chip').forEach(c=>c.onclick=()=>{document.querySelectorAll('#'+id+' .chip').forEach(x=>x.classList.remove('on'));c.classList.add('on');state[k]=p(c);recalc();});}
bind('occChips','occ',c=>c.dataset.occ);bind('prodChips','base',c=>parseInt(c.dataset.base,10));bind('boxChips','box',c=>parseInt(c.dataset.box,10));bind('timeChips','time',c=>c.dataset.time);
function sendQuote(){toast('Quote started','Opening WhatsApp with '+state.occ+' · '+prodName()+' · '+state.qty+' pieces (demo).');}
recalc();
</script></body></html>'''
open(OUT+'/amairee-gifting-hub-mockup.html','w').write(HUB); print("hub written, size %.2fMB"%(len(HUB)/1048576))

for o in OCC:
    uc=''.join('<div class="uccard"><div class="cw">'+MK(*f)+'</div><div class="ucb"><h4>'+t+'</h4><p>'+d+'</p></div></div>' for t,d,f in o["uc"])
    faq=''.join('<div class="faq"><h4>'+q+'</h4><p>'+a+'</p></div>' for q,a in o["faq"])
    page=HEAD('Amairee · '+o["title"]+' gifting')+NAV+'''
<header class="ohero"><div class="wrap"><div class="crumb"><a href="amairee-gifting-hub-mockup.html">Gifting</a> / '''+o["title"]+'''</div>
<div class="ohero-grid"><div><div class="patent-badge">'''+I('seal')+'''Patented · made in Delhi, India</div><h1>'''+o["h1"]+'''</h1><p>'''+o["sub"]+'''</p><div class="cta-row"><a class="btn btn-dark" href="amairee-gifting-hub-mockup.html#quote">Get a bulk quote</a><a class="btn btn-out" href="amairee-gifting-hub-mockup.html#occasions">All occasions</a></div></div>
<div class="hcase">'''+MK(*o["face"])+'''</div></div></div></header>
<section class="wrap"><div class="sec-head"><div class="ek">What we make</div><h2>Ways to gift <em>'''+o["title"].lower()+'''.</em></h2></div><div class="uc">'''+uc+'''</div></section>
'''+o.get("band","")+'''
<section class="wrap" style="padding-top:0;"><div class="caseband"><div class="ek">Case study</div><h3>'''+o["case"][0]+'''</h3><p>'''+o["case"][1]+'''</p></div></section>
<section class="ladder-sec"><div class="wrap"><div class="sec-head"><div class="ek">Bulk pricing</div><h2>Order more, <em>save more.</em></h2><p>Personalisation included at every tier — any quantity, always in stock.</p></div><div class="ladder"><div class="rung"><div class="q">5&ndash;9</div><div class="d">5%</div><div class="n">off</div></div><div class="rung"><div class="q">10&ndash;24</div><div class="d">10%</div><div class="n">off</div></div><div class="rung"><div class="q">25&ndash;49</div><div class="d">15%</div><div class="n">off</div></div><div class="rung"><div class="q">50&ndash;99</div><div class="d">20%</div><div class="n">off + free names</div></div><div class="rung"><div class="q">100+</div><div class="d">Let's talk</div><div class="n">custom + manager</div></div></div></div></section>
'''+SIZES+'''
<section class="wrap"><div class="sec-head"><div class="ek">Good to know</div><h2>'''+o["title"]+''' <em>questions.</em></h2></div><div class="faqs">'''+faq+'''</div><div class="octa"><a class="btn btn-dark" href="amairee-gifting-hub-mockup.html#quote">Start your '''+o["title"].lower()+''' quote</a><div class="pmini">'''+I('refresh')+'''Covered by our Redesign Promise — re-skin it later, never wasted.</div><div class="delhi" style="margin-top:18px;justify-content:center;">Ships to India, US, UK &amp; Canada in 2–7 days</div></div></section>
'''+FOOTER()+'''
<div class="sticky"><a class="b" href="amairee-gifting-hub-mockup.html#occasions">All occasions</a><a class="a" href="amairee-gifting-hub-mockup.html#quote">Get a quote</a></div></body></html>'''
    open(OUT+'/amairee-gifting-'+o["slug"]+'.html','w').write(page); print("occasion:",o["slug"],"%.2fMB"%(len(page)/1048576))
# ---- PARTNER / AMBASSADOR PROGRAM ----
AUD=[('gift','Creators & influencers','Travel, lifestyle and wedding creators who love a beautiful, personal product their audience can actually buy.'),
     ('pen','Wedding & event planners','Recommend personalised luggage for couples, parties and guests — and earn on every booking you send.'),
     ('boxes','Corporate gifting consultants','Procurement and gifting specialists placing branded, bulk orders for teams, clients and events.'),
     ('shield','Happy customers','Already love your Amairee piece? Share your code with friends and earn on what they order.')]
aud_cards=''.join('<div class="who"><div class="wi">'+I(ic)+'</div><h4>'+h+'</h4><p>'+p+'</p></div>' for ic,h,p in AUD)
TIERS=[('','Ambassador','Customers & micro-creators','Commission on every order you send our way',['Your personal referral code &amp; link','Commission on every order placed','One personalised piece to call your own','Featured on @amaireeofficial'],'Apply as an Ambassador'),
       ('Most popular','Creator','Influencers & content partners','A higher rate, plus gifted pieces',['Everything in Ambassador, plus','A higher commission rate','Free gifted piece(s) for content','Custom discount code for your audience','Content support from our studio'],'Apply as a Creator'),
       ('','Pro Partner','Planners, agencies &amp; consultants','Our best rate, plus recurring rewards',['Everything in Creator, plus','Our best commission with volume bonuses','A dedicated gifting manager','Co-branded materials &amp; priority production','Quarterly payouts &amp; reporting'],'Become a Pro Partner')]
tier_cards=''
for badge,name,forwho,earn,perks,cta in TIERS:
    feat=' feat' if badge else ''
    b='<span class="tbadge">'+badge+'</span>' if badge else ''
    lis=''.join('<li>'+x+'</li>' for x in perks)
    btn='btn-dark' if not feat else 'btn-out'
    tier_cards+='<div class="tier'+feat+'">'+b+'<div class="tname">'+name+'</div><div class="tfor">'+forwho+'</div><div class="tearn">'+earn+'</div><ul>'+lis+'</ul><button class="btn '+btn+'" onclick="apply(\''+name+'\')">'+cta+'</button></div>'
PERKS=[('boxes','Free personalised piece','Wear and use the product you recommend — made just for you.'),('refresh','Real commission','Tracked by your code, paid out reliably — not vouchers.'),('seal','A product that sells itself','Patented, personalised, made in India — genuinely unique.'),('pen','Studio content support','We help with mockups and assets so your posts look the part.'),('globe','Worldwide audience','Ships to India, US, UK &amp; Canada in 2–7 days.'),('gift','Early access','First look at new designs, drops and collaborations.')]
perk_cards=''.join('<div class="perk"><span class="pk">'+I(ic)+'</span><div><h5>'+h+'</h5><p>'+p+'</p></div></div>' for ic,h,p in PERKS)
AMB_FAQ=[('Who can apply?','Creators of any size, wedding and event planners, corporate gifting consultants, and happy customers. We care more about a genuine audience than follower counts.'),('How do I get paid?','Every partner gets a unique code and link. We track orders placed through it and pay out by bank transfer (quarterly for Pro Partners, on request thresholds for others).'),('Do I get a free product?','Creators and Pro Partners receive gifted pieces; Ambassadors receive one personalised piece on joining. Final allocation is confirmed at approval.'),('Is the commission really mine to keep?','Yes — your commission is on top of any discount your audience receives with your code, and your exact rate is confirmed in your partner agreement when you join.'),('How do I start?','Tap any apply button to start a chat on WhatsApp, tell us about your audience, and our team sends next steps within 48 hours.')]
amb_faq=''.join('<div class="faq"><h4>'+q+'</h4><p>'+a+'</p></div>' for q,a in AMB_FAQ)

AMB=HEAD('Amairee · Partner Program')+NAV+'''
<header class="ohero"><div class="wrap"><div class="crumb"><a href="amairee-gifting-hub-mockup.html">Gifting</a> / Partner Program</div>
<div class="ohero-grid"><div><div class="patent-badge">'''+I('seal')+'''Patented · made in Delhi, India</div><h1>Wear it. Share it. <em>Earn from it.</em></h1><p>The Amairee Partner Program rewards the people who love our product — creators, planners and happy customers — with real commission on every order they send our way, plus free personalised pieces of their own.</p><div class="cta-row"><button class="btn btn-dark" onclick="scrollTo2('tiers')">See the tiers</button><button class="btn btn-out" onclick="apply('Hero')">Apply now</button><span class="delhi">Made in Delhi, India</span></div></div>
<div class="hcase">'''+MK('D_GOLD_MONOGRAM','PARTNER','block','large')+'''</div></div></div></header>
<div class="capbar"><div class="wrap"><div class="cap"><span class="ci">'''+I('refresh')+'''</span>Real commission, tracked by code</div><div class="cap"><span class="ci">'''+I('gift')+'''</span>Free personalised pieces</div><div class="cap"><span class="ci">'''+I('seal')+'''</span>A genuinely unique product</div><div class="cap"><span class="ci">'''+I('globe')+'''</span>US · UK · CA in 2–7 days</div></div></div>
<section class="wrap"><div class="sec-head"><div class="ek">Who it's for</div><h2>Built for people with <em>an audience to delight.</em></h2><p>If your followers, clients or friends would love a beautiful personalised gift, there's a place for you here.</p></div><div class="who-grid">'''+aud_cards+'''</div></section>
<section id="tiers" class="wrap" style="padding-top:0;"><div class="sec-head"><div class="ek">Tiers</div><h2>Choose your <em>partnership.</em></h2><p>Start where you are and grow. Your exact commission and rewards are agreed with you individually when you join — based on your reach and the orders you drive.</p></div><div class="tiers">'''+tier_cards+'''</div></section>
<section class="ladder-sec"><div class="wrap"><div class="sec-head"><div class="ek">How it works</div><h2>From sign-up to <em>payout.</em></h2></div><div class="flow"><div class="fstep"><div class="fmed"><span class="fi">'''+I('brief')+'''</span></div><div class="fn">Step one</div><h4 style="color:var(--cream)">Apply</h4><p style="color:rgba(250,246,238,.6)">Tell us about your audience on WhatsApp.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('gift')+'''</span></div><div class="fn">Step two</div><h4 style="color:var(--cream)">Get your kit</h4><p style="color:rgba(250,246,238,.6)">Your code, link and a personalised piece.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('globe')+'''</span></div><div class="fn">Step three</div><h4 style="color:var(--cream)">Share</h4><p style="color:rgba(250,246,238,.6)">Post, recommend, or send your code.</p></div><div class="fstep"><div class="fmed"><span class="fi">'''+I('refresh')+'''</span></div><div class="fn">Step four</div><h4 style="color:var(--cream)">Earn</h4><p style="color:rgba(250,246,238,.6)">Commission on every tracked order.</p></div></div></div></section>
<section class="wrap" style="padding-top:0;"><div class="sec-head"><div class="ek">Why partner</div><h2>More than a <em>commission.</em></h2></div><div class="perks">'''+perk_cards+'''</div></section>
<section class="wrap" style="padding-top:0;"><div class="sec-head"><div class="ek">Good to know</div><h2>Partner <em>questions.</em></h2></div><div class="faqs">'''+amb_faq+'''</div><div class="octa"><button class="btn btn-dark" onclick="apply('Footer')">Apply on WhatsApp</button><div class="pmini">'''+I('seal')+'''Reviewed within 48 hours · made in Delhi, India</div></div></section>
<section class="wrap" style="padding-top:0;"><div class="pstrip"><div><h3>Prefer a brand-to-brand partnership?</h3><p>If you represent a brand rather than an audience, explore a co-branded capsule with our collaborations track.</p></div><a class="btn btn-out" href="amairee-gifting-collaborations.html">Explore collaborations &rarr;</a></div></section>
'''+FOOTER()+'''
<div class="sticky"><a class="b" href="amairee-gifting-hub-mockup.html">Gifting</a><button class="a" onclick="apply('Sticky')">Become a partner</button></div><div class="toast" id="toast"></div>
<script>
function scrollTo2(id){document.getElementById(id).scrollIntoView({behavior:'smooth'});}
let tT;function toast(t,m){const e=document.getElementById('toast');e.textContent=m?(t+' — '+m):t;e.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>e.classList.remove('show'),3200);}
function apply(src){toast('Application started','Opening WhatsApp to apply ('+src+', demo).');}
</script></body></html>'''
open(OUT+'/amairee-gifting-ambassador.html','w').write(AMB); print("ambassador written, %.2fMB"%(len(AMB)/1048576))
print("DONE")
